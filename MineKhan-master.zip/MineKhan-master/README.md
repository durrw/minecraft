# MineKhan
Minecraft for Khan Academy

Khan Academy link can be found [here](https://www.khanacademy.org/computer-programming/minekhan/5647155001376768).

GitHub release can be found [here](https://willard21.github.io/MineKhan/index.html).

[Replit post](https://repl.it/talk/share/MineKhan-Minecraft-for-Khan-Academy/87382) and [app](https://replit.com/@Willard21/MineKhan)

Multiplayer [login](https://willard.fun/login) and [game](https://willard.fun/minekhan). This is the most up-to-date version, and I frequenlty code in production on this version. Beware of bugs.


If you'd like to contribute, join the conversation on [Discord](https://discord.gg/j3SzCQU).